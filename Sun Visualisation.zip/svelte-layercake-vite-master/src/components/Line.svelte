<script>
	/**
		Generates an SVG area shape using the `area` function from [d3-shape](https://github.com/d3/d3-shape).
		@type {String} [stroke='#ab00d6'] - The shape's fill color. This is technically optional because it comes with a default value but you'll likely want to replace it with your own color.
	*/
	import { getContext } from 'svelte';

	const { data, xGet, yGet } = getContext('LayerCake');

	export let stroke = '#ab00d6';

	$: path = 'M' + $data
		.map(d => {
			return $xGet(d) + ',' + $yGet(d);
		})
		.join('L');
</script>

<path class='path-line' d='{path}' {stroke}></path>

<style>
	.path-line {
		fill: none;
		stroke-linejoin: round;
		stroke-linecap: round;
		stroke-width: 2;
	}
</style>


